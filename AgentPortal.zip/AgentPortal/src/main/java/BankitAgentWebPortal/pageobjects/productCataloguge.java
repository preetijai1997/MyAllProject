package BankitAgentWebPortal.pageobjects;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BankitAgentWebPortal.AbstratctComponent.AbstractComponent;

public class productCataloguge extends AbstractComponent {

	WebDriver driver;

	public productCataloguge(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[contains(@class, 'mb-3')]")
	List<WebElement> products;

	By ProductsBy = By.xpath("//div[contains(@class, 'mb-3')]");
	By AddToCart = By.xpath("//button[contains(@class,'w-10')]/i");
	By toastMessage=By.id("toast-container");

	public List<WebElement> getProductsList() {
		waitForElementToAppear(ProductsBy);
		System.out.println(products.size());
		return products;

	}

	public WebElement getProductName(String ProductName) {
	WebElement prod=getProductsList().stream().filter(product -> product.findElement(By.xpath("//div[@class='card-body']/h5/b")).getText().equals(ProductName)).findFirst().orElseGet(null);
		 
		
		return prod;
	}

	public void addTocart(String ProductName) {
		WebElement prod = getProductName(ProductName);
		System.out.println(prod);
//      //prod.findElement(AddToCart).click();
//	  //waitForElementToAppear(toastMessage);
//	}

}
}
